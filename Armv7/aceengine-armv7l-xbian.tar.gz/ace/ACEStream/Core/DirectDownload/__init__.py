#Embedded file name: ACEStream\Core\DirectDownload\__init__.pyo
pass
